#include<math.h>
#include<stdio.h>

