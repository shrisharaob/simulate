#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "nr.h"
#include "nrutil.h"
#include "globalVars.h"
//void (*derive)(double, double *, double *);

// GLOBAL VARS
extern double **y, *xx;

void main(int argc, char **argv) {
    int dim = 2;
    int nSteps = 800;
    double *vstart;
    double x1 = 0;
    double x2 = 100;
    FILE *fp;
    int loopIdx=0;

    xx = vector(1, nSteps);
    y = matrix(1, dim, 1, nSteps);
    vstart = vector(1, dim);
    vstart[1] = 1;
    vstart[2] = 0;
  
    rkdumb(vstart, dim, x1, x2, nSteps, derive);
    fp = fopen("outputFile.csv", "w");
    for(loopIdx = 1; loopIdx < nSteps+1; ++loopIdx) 
      {
	fprintf(fp, "%f %f %f\n", xx[loopIdx], y[1][loopIdx], y[2][loopIdx]);
	printf("%f %f %f\n", xx[loopIdx], y[1][loopIdx], y[2][loopIdx]);
      }

    fclose(fp);
    //    free_vector(xx, 1, nSteps);
    //    free_matrix(y, 1, dim, 1, nSteps);
  }   
