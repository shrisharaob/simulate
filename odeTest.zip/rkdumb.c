/* driver for the algorithm "rk4.c" */



/* ************************************************************ */
/* ************************************************************ */
/*        This routine DOES NOT save EVERY TIMESTEP!!!          */  
/* ************************************************************ */
/* ************************************************************ */


#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "nrutil.h"
#include "nr.h"
//#include "xpyrint_var.h"
//#include "xpyrint_func.h" 

double **y, *xx;

void rkdumb(double vstart[], int nvar, double x1, double x2, int nstep, void (*derivs)(double, double [], double []))

{ 
  void rk4(double y[], double dydx[], int n,  double x, double h, 
	   double yout[], void (*derivs)(double, double [], double []));
  
  int i, k;
  double x, h;
  double *v, *vout, *dv;
  v = vector(1,nvar);
  vout = vector(1,nvar);
  dv = vector(1,nvar);
  
  //*** START ***//
  for (i=1;i<=nvar;i++) 
    {
      v[i] = vstart[i];
      y[i][1] = v[i];
    }
  // break here and check v
  //*** TIMELOOP ***//
  xx[1] = x1;  
  x = x1;
  h = (x2 - x1) / nstep;
  
  for (k = 1; k <= nstep; k++) 
    {
      (*derivs)(x,v,dv);
      rk4(v,dv,nvar,x,h,vout,derivs);
      if ((double)(x+h) == x) nrerror("Step size too small in routine rkdumb");
      x += h;
      xx[k+1] = x;
      
      /* RENAME */  
      for (i=1;i<=nvar;i++) 
	{
	  v[i]=vout[i];
	  y[i][k+1] = v[i];
	}
    }
  free_vector(v,1,nvar);
  free_vector(vout,1,nvar);
  free_vector(dv,1,nvar);
 }
#undef NRANSI
/* (C) Copr. 1986-92 Numerical Recipes Software 9,)5. */
